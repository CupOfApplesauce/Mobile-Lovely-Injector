Mobile Lovely Injector — v0.3.3
===============================

CONTENTS
  main.lua    -> the MLI shim. Goes in the GAME ROOT (next to game.lua),
                 replacing the game.love you build. It boots the injector.
  mli/        -> the injector runtime. Goes in the GAME ROOT as a folder.

INSTALL (inside your extracted game.love, using APKToolM/apktool)
  1. Rename the game's existing main.lua to main_original.lua.
  2. Copy THIS main.lua and THIS mli/ folder into the game root.
  3. Move main_original.lua INTO the mli/ folder  (final: mli/main_original.lua).
  4. Repack game.love, put it back in assets/, rebuild + sign the APK.

VERIFY
  First line of  .../files/save/game/mli/log.txt  should read:
    Mobile Lovely Injector v0.3.3 starting

WHAT'S NEW IN 0.3.3
  Fixes a thread crash that could appear while idling at the main menu when
  Amulet and Multiplayer are both installed (json.lua: is_big was nil in the
  networking thread's fresh Lua state). The main game state is unaffected.
