MLI Mods Starter
================
Drop these folders into  /storage/emulated/0/Download/Mods/  (alongside
Steamodded and any content mods). Each is a normal mod folder.

  SmodsColourGuard  REQUIRED. Prevents a rare Steamodded tooltip crash
                    (guards a nil-colour lookup in SMODS.localize_box).
  AtlasMemFix       RECOMMENDED. Frees the redundant CPU copy of each atlas
                    after its GPU texture is built. Lowers memory, no visual
                    change. Safe to keep installed everywhere.
  LowResTextures    OPTIONAL (low-RAM phones). Forces 1x textures to cut
                    texture memory ~4x. Trade-off: lower-res sprites. Try
                    AtlasMemFix alone first; add this only if the game still
                    force-closes on the long first boot.
  HelloMod          OPTIONAL. A tiny example/signature mod and a template for
                    writing your own MLI-compatible mods.

NOTE: AtlasMemFix and SmodsColourGuard patch Steamodded's own source by exact
lines, so they are matched to the Steamodded version MLI was tested against.
Use that version; a newer Steamodded may silently stop these from applying.
